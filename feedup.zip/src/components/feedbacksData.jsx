// feedbacksData.jsx

export const feedbacksData = [
  {
    id: 1,
    author: 'Fernando Santiago',
    photo: require('../assets/image.png'),
    dateTime: '2 dias atrás',
    text: '@Giovana, sua liderança no desenvolvimento do aplicativo da Havan foi incrível! 💻 Sua habilidade de coordenar equipes e gerenciar prazos foi essencial para o sucesso do projeto.',
    liked: false,
  },
  {
    id: 2,
    author: 'Paula Martins',
    photo: require('../assets/image.png'),
    dateTime: '3 dias atrás',
    text: '@Carolina, gostaria de reconhecer sua contribuição no projeto de otimização de processos! 🔄',
    liked: false,
  },
  {
    id: 3,
    author: 'Bernardo Alvim',
    photo: require('../assets/image.png'),
    dateTime: '4 dias atrás',
    text: '@Gabriela, a criatividade da Gabi na concepção das campanhas de marketing é surreal!!',
    liked: false,
  },
  {
    id: 4,
    author: 'Fernando Santiago',
    photo: require('../assets/image.png'),
    dateTime: '5 dias atrás',
    text: '@Laura, estou impressionado com sua dedicação aos detalhes! Você realmente faz a diferença na nossa equipe!!',
    liked: false,
  },
  {
    id: 5,
    author: 'Isabella Stefanni',
    photo: require('../assets/image.png'),
    dateTime: '6 dias atrás',
    text: '@Gabriela, a criatividade da Gabi na concepção das campanhas de marketing é surreal!!',
    liked: false,
  },
];
